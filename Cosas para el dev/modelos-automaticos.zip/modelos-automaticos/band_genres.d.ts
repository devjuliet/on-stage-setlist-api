import { Model, BuildOptions } from 'sequelize';
export interface IBandGenresAttributes {
  id_band_genre: number,
  id_band: number,
  id_genre: number,
}
export interface IBandGenresModel extends IBandGenresAttributes, Model {}
export type IBandGenresModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): IBandGenresModel;
};