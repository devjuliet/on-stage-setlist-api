import { Model, BuildOptions } from 'sequelize';
export interface IBandsAttributes {
  id_band: number,
  name: string,
  url_logo?: string,
  description: string,
  id_user_manager: number,
}
export interface IBandsModel extends IBandsAttributes, Model {}
export type IBandsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): IBandsModel;
};