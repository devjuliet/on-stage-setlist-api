import { Model, BuildOptions } from 'sequelize';
export interface IUserHistoryAttributes {
  id_user_history: number,
  date: Date,
  description: string,
  id_user: number,
  band_name: string,
}
export interface IUserHistoryModel extends IUserHistoryAttributes, Model {}
export type IUserHistoryModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): IUserHistoryModel;
};