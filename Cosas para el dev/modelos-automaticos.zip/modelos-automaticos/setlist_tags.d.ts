import { Model, BuildOptions } from 'sequelize';
export interface ISetlistTagsAttributes {
  id_setlist_tag: number,
  id_setlist: number,
  id_tag: number,
}
export interface ISetlistTagsModel extends ISetlistTagsAttributes, Model {}
export type ISetlistTagsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ISetlistTagsModel;
};