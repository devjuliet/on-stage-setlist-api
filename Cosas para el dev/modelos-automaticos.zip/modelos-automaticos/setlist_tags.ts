import { Sequelize, DataTypes } from 'sequelize';
export default function (sequelize: Sequelize) {
  const attributes = {
    id_setlist_tag: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: true,
      autoIncrement: false,
      comment: null,
      field: "id_setlist_tag"
    },
    id_setlist: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_setlist",
      references: {
        key: "id_setlist",
        model: "setlists_model"
      }
    },
    id_tag: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_tag",
      references: {
        key: "id_tag",
        model: "tags_model"
      }
    }
  };
  const options = {
    tableName: "setlist_tags",
    comment: "",
    indexes: [{
      name: "setlist_tags_FK",
      unique: false,
      type: "BTREE",
      fields: ["id_setlist"]
    }, {
      name: "setlist_tags_FK_1",
      unique: false,
      type: "BTREE",
      fields: ["id_tag"]
    }]
  };
  const SetlistTagsModel = sequelize.define("setlist_tags_model", attributes, options);
  return SetlistTagsModel;
}