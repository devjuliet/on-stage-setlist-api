import { Model, BuildOptions } from 'sequelize';
export interface ISetsAttributes {
  id_set: number,
  name: string,
}
export interface ISetsModel extends ISetsAttributes, Model {}
export type ISetsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ISetsModel;
};