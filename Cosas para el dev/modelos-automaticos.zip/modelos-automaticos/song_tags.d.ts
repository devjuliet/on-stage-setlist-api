import { Model, BuildOptions } from 'sequelize';
export interface ISongTagsAttributes {
  id_song_tag: number,
  id_tag: number,
  id_song: number,
}
export interface ISongTagsModel extends ISongTagsAttributes, Model {}
export type ISongTagsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ISongTagsModel;
};