import { Sequelize, DataTypes } from 'sequelize';
export default function (sequelize: Sequelize) {
  const attributes = {
    id_setlist: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: true,
      autoIncrement: true,
      comment: null,
      field: "id_setlist"
    },
    id_live_event: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_live_event",
      references: {
        key: "id_live_event",
        model: "live_events_model"
      }
    },
    id_band: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_band",
      references: {
        key: "id_band",
        model: "bands_model"
      }
    },
    name: {
      type: DataTypes.STRING(200),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "name"
    }
  };
  const options = {
    tableName: "setlists",
    comment: "",
    indexes: [{
      name: "setlists_FK",
      unique: false,
      type: "BTREE",
      fields: ["id_live_event"]
    }, {
      name: "setlists_FK_1",
      unique: false,
      type: "BTREE",
      fields: ["id_band"]
    }]
  };
  const SetlistsModel = sequelize.define("setlists_model", attributes, options);
  return SetlistsModel;
}