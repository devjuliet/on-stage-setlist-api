import { Model, BuildOptions } from 'sequelize';
export interface ISetSongsAttributes {
  id_set_songs: number,
  id_set: number,
  id_song: number,
}
export interface ISetSongsModel extends ISetSongsAttributes, Model {}
export type ISetSongsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ISetSongsModel;
};