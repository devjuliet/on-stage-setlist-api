import { Sequelize, DataTypes } from 'sequelize';
export default function (sequelize: Sequelize) {
  const attributes = {
    id_live_event_tags: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: true,
      autoIncrement: true,
      comment: null,
      field: "id_live_event_tags"
    },
    id_tag: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_tag",
      references: {
        key: "id_tag",
        model: "tags_model"
      }
    },
    id_live_event: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_live_event",
      references: {
        key: "id_live_event",
        model: "live_events_model"
      }
    }
  };
  const options = {
    tableName: "live_event_tags",
    comment: "",
    indexes: [{
      name: "live_event_tags_FK",
      unique: false,
      type: "BTREE",
      fields: ["id_tag"]
    }, {
      name: "live_event_tags_FK_1",
      unique: false,
      type: "BTREE",
      fields: ["id_live_event"]
    }]
  };
  const LiveEventTagsModel = sequelize.define("live_event_tags_model", attributes, options);
  return LiveEventTagsModel;
}