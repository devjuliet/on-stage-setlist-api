import { Model, BuildOptions } from 'sequelize';
export interface ITagsAttributes {
  id_tag: number,
  name: string,
}
export interface ITagsModel extends ITagsAttributes, Model {}
export type ITagsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ITagsModel;
};