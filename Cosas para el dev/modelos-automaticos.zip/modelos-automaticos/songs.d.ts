import { Model, BuildOptions } from 'sequelize';
export interface ISongsAttributes {
  id_song: number,
  name: string,
  artist: string,
  lyric: string,
  chords_guitar?: string,
  tab_guitar?: string,
  chords_bass?: string,
  tab_bass?: string,
  chords_piano?: string,
  tab_piano?: string,
  tempo: number,
}
export interface ISongsModel extends ISongsAttributes, Model {}
export type ISongsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ISongsModel;
};