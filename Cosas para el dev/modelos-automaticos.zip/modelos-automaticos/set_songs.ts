import { Sequelize, DataTypes } from 'sequelize';
export default function (sequelize: Sequelize) {
  const attributes = {
    id_set_songs: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: true,
      autoIncrement: true,
      comment: null,
      field: "id_set_songs"
    },
    id_set: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_set",
      references: {
        key: "id_set",
        model: "sets_model"
      }
    },
    id_song: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_song",
      references: {
        key: "id_song",
        model: "songs_model"
      }
    }
  };
  const options = {
    tableName: "set_songs",
    comment: "",
    indexes: [{
      name: "set_songs_FK",
      unique: false,
      type: "BTREE",
      fields: ["id_set"]
    }, {
      name: "set_songs_FK_1",
      unique: false,
      type: "BTREE",
      fields: ["id_song"]
    }]
  };
  const SetSongsModel = sequelize.define("set_songs_model", attributes, options);
  return SetSongsModel;
}