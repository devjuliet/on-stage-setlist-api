import { Model, BuildOptions } from 'sequelize';
export interface ILiveEventsAttributes {
  id_live_event: number,
  location: string,
  name: string,
  tour: string,
  date: Date,
  place: string,
  id_band: number,
  tag: string,
}
export interface ILiveEventsModel extends ILiveEventsAttributes, Model {}
export type ILiveEventsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ILiveEventsModel;
};