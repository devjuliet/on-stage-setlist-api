import { Model, BuildOptions } from 'sequelize';
export interface ILiveEventTagsAttributes {
  id_live_event_tags: number,
  id_tag: number,
  id_live_event: number,
}
export interface ILiveEventTagsModel extends ILiveEventTagsAttributes, Model {}
export type ILiveEventTagsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ILiveEventTagsModel;
};