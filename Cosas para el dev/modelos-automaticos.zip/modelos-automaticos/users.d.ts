import { Model, BuildOptions } from 'sequelize';
export interface IUsersAttributes {
  id_user: number,
  name: string,
  email: string,
  password: string,
  type: number,
  username: string,
}
export interface IUsersModel extends IUsersAttributes, Model {}
export type IUsersModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): IUsersModel;
};