import { Model, BuildOptions } from 'sequelize';
export interface ISetlistSetsAttributes {
  is_setlist_set: number,
  id_setlist: number,
  id_set: number,
}
export interface ISetlistSetsModel extends ISetlistSetsAttributes, Model {}
export type ISetlistSetsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ISetlistSetsModel;
};