import { Sequelize, DataTypes } from 'sequelize';
export default function (sequelize: Sequelize) {
  const attributes = {
    id_live_designer: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: true,
      autoIncrement: true,
      comment: null,
      field: "id_live_designer"
    },
    id_user_designer: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_user_designer",
      references: {
        key: "id_user",
        model: "users_model"
      }
    },
    id_band: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_band",
      references: {
        key: "id_band",
        model: "bands_model"
      }
    }
  };
  const options = {
    tableName: "live_designers",
    comment: "",
    indexes: [{
      name: "live_designer_FK",
      unique: false,
      type: "BTREE",
      fields: ["id_user_designer"]
    }, {
      name: "live_designer_FK_1",
      unique: false,
      type: "BTREE",
      fields: ["id_band"]
    }]
  };
  const LiveDesignersModel = sequelize.define("live_designers_model", attributes, options);
  return LiveDesignersModel;
}