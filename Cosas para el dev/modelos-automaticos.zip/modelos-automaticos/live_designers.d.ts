import { Model, BuildOptions } from 'sequelize';
export interface ILiveDesignersAttributes {
  id_live_designer: number,
  id_user_designer: number,
  id_band: number,
}
export interface ILiveDesignersModel extends ILiveDesignersAttributes, Model {}
export type ILiveDesignersModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ILiveDesignersModel;
};