import { Sequelize, DataTypes } from 'sequelize';
export default function (sequelize: Sequelize) {
  const attributes = {
    id_band_genre: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: true,
      autoIncrement: true,
      comment: null,
      field: "id_band_genre"
    },
    id_band: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_band",
      references: {
        key: "id_band",
        model: "bands_model"
      }
    },
    id_genre: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_genre",
      references: {
        key: "id_genre",
        model: "genres_model"
      }
    }
  };
  const options = {
    tableName: "band_genres",
    comment: "",
    indexes: [{
      name: "band_genres_FK",
      unique: false,
      type: "BTREE",
      fields: ["id_band"]
    }, {
      name: "band_genres_FK_1",
      unique: false,
      type: "BTREE",
      fields: ["id_genre"]
    }]
  };
  const BandGenresModel = sequelize.define("band_genres_model", attributes, options);
  return BandGenresModel;
}