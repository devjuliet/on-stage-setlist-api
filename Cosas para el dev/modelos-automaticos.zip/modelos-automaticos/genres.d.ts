import { Model, BuildOptions } from 'sequelize';
export interface IGenresAttributes {
  id_genre: number,
  name?: string,
}
export interface IGenresModel extends IGenresAttributes, Model {}
export type IGenresModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): IGenresModel;
};