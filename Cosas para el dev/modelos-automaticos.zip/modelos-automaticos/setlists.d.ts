import { Model, BuildOptions } from 'sequelize';
export interface ISetlistsAttributes {
  id_setlist: number,
  id_live_event: number,
  id_band: number,
  name: string,
}
export interface ISetlistsModel extends ISetlistsAttributes, Model {}
export type ISetlistsModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): ISetlistsModel;
};