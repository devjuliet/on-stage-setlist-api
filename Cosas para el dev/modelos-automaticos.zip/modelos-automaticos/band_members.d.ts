import { Model, BuildOptions } from 'sequelize';
export interface IBandMembersAttributes {
  id_member: number,
  role: number,
  id_user: number,
  id_band: number,
}
export interface IBandMembersModel extends IBandMembersAttributes, Model {}
export type IBandMembersModelStatic = typeof Model & {
  new (values?: object, options?: BuildOptions): IBandMembersModel;
};