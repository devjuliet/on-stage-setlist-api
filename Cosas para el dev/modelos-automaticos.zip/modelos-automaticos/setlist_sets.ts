import { Sequelize, DataTypes } from 'sequelize';
export default function (sequelize: Sequelize) {
  const attributes = {
    is_setlist_set: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: true,
      autoIncrement: false,
      comment: null,
      field: "is_setlist_set"
    },
    id_setlist: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_setlist",
      references: {
        key: "id_setlist",
        model: "setlists_model"
      }
    },
    id_set: {
      type: DataTypes.INTEGER(11),
      allowNull: false,
      defaultValue: null,
      primaryKey: false,
      autoIncrement: false,
      comment: null,
      field: "id_set",
      references: {
        key: "id_set",
        model: "sets_model"
      }
    }
  };
  const options = {
    tableName: "setlist_sets",
    comment: "",
    indexes: [{
      name: "setlist_sets_FK",
      unique: false,
      type: "BTREE",
      fields: ["id_setlist"]
    }, {
      name: "setlist_sets_FK_1",
      unique: false,
      type: "BTREE",
      fields: ["id_set"]
    }]
  };
  const SetlistSetsModel = sequelize.define("setlist_sets_model", attributes, options);
  return SetlistSetsModel;
}